import { Facebook, Instagram, Twitter, Github } from "lucide-react";
import Link from "next/link";

const Footer = () => {
  const companys = [
    {
      title: "Tentang Kami",
      href: "/about-us",
    },
    {
      title: "Bantuan",
      href: "/form-help",
    },
    {
      title: "Kontak",
      href: "/about",
    },
  ];

  return (
    <footer className="bg-gray-900 text-white py-10">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">
            🌐 {process.env.NEXT_PUBLIC_COMPANY_NAME}
          </h1>
          <p className="text-sm text-gray-400">
            {process.env.NEXT_PUBLIC_DESCRIPTION_FOOTER}
          </p>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-3">Perusahaan</h2>
          {companys.map((company, i) => (
            <ul className="space-y-2 text-sm text-gray-300" key={i}>
              <li>
                <Link
                  href={company.href}
                  className="transition font-semibold underline"
                >
                  {company.title}
                </Link>
              </li>
            </ul>
          ))}
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-3">Sosial Media</h2>
          <div className="flex space-x-4">
            <a href="#" aria-label="Facebook">
              <Facebook className="h-5 w-5 hover:text-blue-500" />
            </a>
            <a href="#" aria-label="Telegram">
              <Twitter className="h-5 w-5 hover:text-blue-400" />
            </a>
            <a href="#" aria-label="Instagram">
              <Instagram className="h-5 w-5 hover:text-pink-500" />
            </a>
            <a href="#" aria-label="Github">
              <Github className="h-5 w-5 hover:text-gray-300" />
            </a>
          </div>
        </div>
      </div>

      <div className="mt-10 border-t border-gray-700 pt-4 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} {process.env.NEXT_PUBLIC_COMPANY_NAME}. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
