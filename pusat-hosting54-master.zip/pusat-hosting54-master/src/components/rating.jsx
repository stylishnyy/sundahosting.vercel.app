

function Rating() {
  return (
    <>
      <div className="flex justify-center items-center mt-16 sticky top-0">
        <Card className="w-[350px]">
          <CardHeader>
            <CardTitle>Kata orang orang</CardTitle>
          </CardHeader>
        </Card>
      </div>
    </>
  );
}

export default Rating;
