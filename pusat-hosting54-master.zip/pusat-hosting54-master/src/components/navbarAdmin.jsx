"use client";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function NavbarAdmin() {
  const [isOpen, setIsOpen] = useState(false);
  const router = useRouter();

  return (
    <nav className="bg-transparent shadow-md border-b sticky top-0 transition-all ease-in-out duration-300 transform backdrop-blur-lg z-10 will-change-transform px-6 py-4">
      <div className="flex justify-between items-center w-full max-w-7xl">
        <h1 className="font-bold text-xl text-black">Admin Panel</h1>

        <div className="hidden md:flex items-center space-x-6">
          <Link
            href="/admin/dashboard"
            className="hover:text-blue-600 transition font-bold underline"
          >
            Beranda
          </Link>
          <Link
            href="/admin/dashboard/add-product"
            className="hover:text-blue-600 transition font-bold underline"
          >
            Tambah produk
          </Link>
          <Link
            href="/admin/dashboard/delete-product"
            className="hover:text-blue-600 transition font-bold underline"
          >
            Hapus produk
          </Link>
        </div>

        <Button
          variant="default"
          className="md:hidden"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? (
            <X size={24} color="white" />
          ) : (
            <Menu size={24} color="white" />
          )}
        </Button>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="md:hidden mt-4 space-y-3 flex flex-col bg-white p-4 rounded-lg shadow-lg absolute top-full left-0 right-0 z-50"
            initial={{ opacity: 0, height: 0, y: -20 }}
            animate={{ opacity: 1, height: "auto", y: 0 }}
            exit={{ opacity: 0, height: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <Link href="/admin/dashboard" className="hover:text-blue-600 font-bold transition underline">
              Beranda
            </Link>
            <Link
              href="/admin/dashboard/add-product"
              className="hover:text-blue-600 font-bold transition underline"
            >
              Tambah produk
            </Link>
            <Link
              href="/admin/dashboard/delete-product"
              className="hover:text-blue-600 font-bold transition underline"
            >
              Hapus produk
            </Link>
            <Button
              onClick={() => {
                document.cookie = "role=admin; path=/; max-age=0;";
                router.push("/admin");
                toast("Sukses logout", {
                  description: `© ${new Date().getFullYear()} ${
                    process.env.NEXT_PUBLIC_COMPANY_NAME
                  }.`,
                  action: {
                    label: "X",
                  },
                });
              }}
            >
              Logout
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
