"use client";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-transparent shadow-md border-b sticky top-0 transition-all ease-in-out duration-300 transform backdrop-blur-lg z-10 will-change-transform px-6 py-4">
      <div className="flex justify-between items-center w-full max-w-7xl">
        <h1 className="font-bold text-xl text-black">{ process.env.NEXT_PUBLIC_COMPANY_NAME }</h1>

        <div className="hidden md:flex items-center space-x-6">
          <Link
            href="/"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Beranda
          </Link>
          <Link
            href="/#unggulan"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Unggulan Kami
          </Link>
          <Link
            href="/#testimoni"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Testimoni
          </Link>
          <Link
            href="/product"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Belanja
          </Link>
        </div>

        <Button
          variant="default"
          className="md:hidden"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? (
            <X size={24} color="white" />
          ) : (
            <Menu size={24} color="white" />
          )}
        </Button>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="md:hidden mt-4 space-y-3 flex flex-col bg-white p-4 rounded-lg shadow-lg absolute top-full left-0 right-0 z-50"
            initial={{ opacity: 0, height: 0, y: -20 }}
            animate={{ opacity: 1, height: "auto", y: 0 }}
            exit={{ opacity: 0, height: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <Link
            href="/"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Beranda
          </Link>
          <Link
            href="/#unggulan"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Unggulan Kami
          </Link>
          <Link
            href="/#testimoni"
            className="hover:text-blue-600 transition font-semibold underline"
          >
            Testimoni
          </Link>
            <Button asChild>
              <Link href="/product">Belanja sekarang</Link>
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
