import { PrismaClient } from "@/generated/prisma";
const prisma = new PrismaClient();

export async function POST(req, { params }) {
  const { view } = params;

  try {
    const addView = await prisma.visitor.create({
      data: {
        count: parseInt(view)
      },
    });

    return Response.json(addView);
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Failed to add view" }),
      { status: 500 }
    );
  }
}
