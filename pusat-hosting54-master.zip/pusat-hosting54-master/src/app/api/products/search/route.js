import { PrismaClient } from "@/generated/prisma";
const prisma = await new PrismaClient(); 

export async function GET() {
    try {
        const totalProducts = await prisma.product.count();
        return Response.json(totalProducts)
    } catch (err) {
        console.error("Error", err)
        return Response.json({
            error: "Error:", err
        }, {status: 500})
    }
}