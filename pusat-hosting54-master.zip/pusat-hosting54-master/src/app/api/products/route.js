import { PrismaClient } from "@/generated/prisma";

const prisma = new PrismaClient();

export async function GET(req) {
    if(req.method === 'GET') {
        const products = await prisma.product.findMany();
        return Response.json(products)
    }
}

export async function POST(req) {
    
    if(req.method === 'POST') {
        const body = await req.json();
        const {name, price, description, image} = body;

        if(!name || !price) {
            return new Response(
                JSON.stringify({
                    message: "name and price must fill"
                }),
                { status: 400 }
            )
        }

        const product = await prisma.product.create({
            data: {
                name,
                price: parseInt(price),
                description,
                image
            },
        });

        return Response.json(product, {status: 201});
     }
}