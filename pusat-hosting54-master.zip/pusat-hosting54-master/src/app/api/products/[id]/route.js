import { PrismaClient } from "@/generated/prisma";
const prisma = new PrismaClient();

export async function DELETE(req, { params }) {
  const { id } = params;

  if (req.method === "DELETE") {
    try {
      const deletedProduct = await prisma.product.delete({
        where: { id: parseInt(id) },
      });
      return Response.json(deletedProduct);
    } catch (err) {
      return new Response(
        JSON.stringify({
          error: "Failed to deleted product",
        }),
        { status: 500 }
      );
    }
  }
}

export async function POST(req, { params }) {
  const { view } = params;

  if (req.method === "POST") {
    try {
        const addView = await prisma.visitor.create({
        data: {
          view,
        },
      });
    return Response.json(addView);

    } catch (err) {
      return new Response(
        JSON.stringify({
          error: "Failed to deleted product",
        }),
        { status: 500 }
      );
    }

  }
}
