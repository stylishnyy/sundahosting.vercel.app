"use client";
import Navbar from "@/components/navbar";
import TypeIt from "typeit";
import { useEffect, useRef } from "react";
import { Star } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import AOS from "aos";
import "aos/dist/aos.css";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import Footer from "@/components/footer";
import Link from "next/link";
import axios from "axios";
import { useRouter } from "next/navigation";

const Home = () => {
  const typeItInstance = useRef(null);
  const router = useRouter();
  useEffect(() => {
    if (!typeItInstance.current) {
      const instance = new TypeIt("#element", {
        strings: [
          "Selamat datang",
          `di ${process.env.NEXT_PUBLIC_COMPANY_NAME}`,
        ],
        speed: 70,
        waitUntilVisible: true,
        loop: true,
      });

      instance.go();
      typeItInstance.current = instance;
    }
  }, []);

  const addVisitor = async (id) => {
    // Langsung redirect ke halaman lain
    router.push("/product");

    // Kirim request ke API setelah redirect
    try {
      await axios.post(`/api/views/${id}`);
    } catch (err) {
      console.error("Error:", err);
    }
  };

  return (
    <>
      <Navbar />
      <HeroSection />
      <div className="flex justify-center mt-16 cursor-pointer">
        <Button onClick={() => addVisitor(1)}>Belanja Sekarang</Button>
      </div>
      <Superiority />
      <ReviewSection />
      <Faq />
      <Footer />
    </>
  );
};

const HeroSection = () => (
  <div className="relative mt-28 h-[60px]">
    <h1
      className="font-bold text-3xl text-center absolute w-full"
      id="element"
    ></h1>
  </div>
);

const Superiority = () => {
  useEffect(() => {
    AOS.init();
  }, []);

  const fills = [
    {
      title: "Hosting 🌎",
      description:
        "Hosting cepat & stabil untuk website pribadi, bisnis, atau blog. cocok untuk semua kalangan.",
    },
    {
      title: "Course Web Dev 💻",
      description:
        "untuk mempelajari dasar pembuatan website html, css, javascript.",
    },
    {
      title: "Sewa Domain 🔗",
      description:
        "Dapatkan domain pilihan dengan harga terbaik! Berbagai pilihan ekstensi domain populer, seperti .com, .net, .org, dan .id. Semua bisa didaftarkan langsung lewat kami, praktis dan aman!",
    },
    {
      title: "PO Server WHM 🛒",
      description:
        "Dapatkan web server WHM dengan harga terbaik! Dijamin server 100% scalable dan super cepat.",
    },
  ];

  return (
    <section className="bg-white py-16 px-6" id="unggulan">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-5 underline">
          Fitur Unggulan Kami
        </h2>
        <div className="grid md:grid-cols-3 gap-4">
          {fills.map((fill, i) => (
            <Card key={i} data-aos="zoom-in-up" data-aos-duration="500">
              <CardHeader>
                <CardTitle className="text-xl font-bold ">
                  {fill.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{fill.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const ReviewSection = () => {
  const reviews = [
    {
      name: "Rahmat Toyota",
      rating: 5,
      comment: "Hosting disini sangat murah dan memuaskan.",
    },
    { name: "Reza Auditore", rating: 3, comment: "Not bad lah." },
    { name: "Grizzman", rating: 4, comment: "lebih fast respon lain kali." },
    {
      name: "Aldog Furry",
      rating: 2,
      comment: "gila domain blm ada 1 bulan udah ke suspend.",
    },
    { name: "Tung Sahur", rating: 5, comment: "Baik." },
    { name: "Ryan Palembang", rating: 4, comment: "seperti pada umumnya" },
  ];

  useEffect(() => {
    AOS.init();
  }, []);

  return (
    <section className="bg-white py-16 px-6" id="testimoni">
      <div className="max-w-7xl mx-auto grid">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-5 underline">
          Testimoni Toko Kami
        </h2>
        {reviews.map((review, i) => (
          <Card
            key={i}
            className="w-[310px] mb-3"
            data-aos="zoom-in-up"
            data-aos-duration="500"
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage
                    src={`https://avatar.iran.liara.run/public/${i}`}
                  />
                  <AvatarFallback>PH54</AvatarFallback>
                </Avatar>
              </div>
              <CardTitle>{review.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center gap-1 mb-2">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star
                    key={index}
                    className={`h-4 w-4 ${
                      index < review.rating
                        ? "text-yellow-400"
                        : "text-gray-300"
                    }`}
                    fill={index < review.rating ? "currentColor" : "none"}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground">{review.comment}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};

const Faq = () => {
  const faqs = [
    {
      question: "Kenapa harus kita?",
      answer: `${process.env.NEXT_PUBLIC_COMPANY_NAME} layanan kebutuhan hosting lainnya lebih murah dan berkualitas!`,
    },
    {
      question: "Apakah dana akan dikembalikan jika ada kendala?",
      answer: "Uang 100% kembali jika ada kendala yang tidak di inginkan.",
    },
    {
      question: "Apakah ini scalable?",
      answer: "Tentu, server kita sudah dijamin scalable.",
    },
    {
      question: "Pelayanan 24/7 jam?",
      answer: "Kita siap membantu customer 24/7 jam.",
    },
  ];

  return (
    <div className="grid grid-cols-1 mb-5 mx-auto place-items-center justify-center items-center gap-4" id="faq">
      <h2 className="text-2xl font-bold text-center text-gray-800 underline">
        FAQ
      </h2>
      <div className="justify-center items-center grid grid-cols-1 mx-auto w-[40vh] md:w-[100vh]">
        <Accordion type="single" collapsible>
          {faqs.map((faq, i) => (
            <AccordionItem key={i} value={`item-${i}`}>
              <AccordionTrigger className={"font-bold"}>
                {faq.question}
              </AccordionTrigger>
              <AccordionContent>{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
};

export default Home;
