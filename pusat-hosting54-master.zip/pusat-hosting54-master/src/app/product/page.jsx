"use client";
import Navbar from "@/components/navbar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Image } from "lucide-react";
import { use, useEffect, useState } from "react";
import axios from "axios";
import Link from "next/link";
import Footer from "@/components/footer";

const Home = () => {
  return (
    <>
      <Navbar />
      <SearchBar />
      <ProductCard />
      <Footer />
    </>
  );
};

const SearchBar = () => {
  const [total, setTotal] = useState(null);

  useEffect(() => {
    const fetchTotal = async () => {
      try {
        axios
          .get("/api/products/search")
          .then((res) => {
            setTotal(res.data);
          })
          .catch((err) => {
            console.error("Error:", err);
          });
      } catch (err) {
        console.error("Gagal fetch total produk:", err);
      }
    };

    fetchTotal();
  }, []);

  return (
    <div className="flex justify-center items-center mt-8">
        <Button>Total Produk: {total !== null ? total : 'Loading...'}</Button>
    </div>
  );
};

const ProductCard = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios
      .get("/api/products")
      .then((res) => {
        setProducts(res.data);
      })
      .catch((err) => {
        console.error("Error:", err);
      });
  }, []);

  return (
    <section className="bg-white py-16 px-6">
      <div className="max-w-7xl mx-auto grid">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-5 underline">
          Produk Kami
        </h2>
        {products.map((item) => (
          <Card className={"mb-5"} key={item.id}>
            <CardHeader>
              <CardTitle>{item.name}</CardTitle>
              <CardDescription>{item.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 space-y-4">
                <img src={item.image} alt="" width={350} height={350} />
                <p className="text-center font-poppin font-bold underline">
                  Harga: Rp {item.price.toLocaleString()}
                </p>
                <Button asChild>
                  <Link href={`https://wa.me/6283146248417?text=Halo,+saya+mau+beli+${encodeURIComponent(item.name)}`}>
                    Beli
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default Home;
