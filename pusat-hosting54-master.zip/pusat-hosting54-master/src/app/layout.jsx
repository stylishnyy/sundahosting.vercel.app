import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Poppins } from "next/font/google";
import { Toaster } from "@/components/ui/sonner";

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'], // pilih berat sesuai kebutuhan
  variable: '--font-poppins', // biar bisa dipanggil dari Tailwind
  display: 'swap',
})


const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "Pusathosting54",
  description: "Sebuah tempat yang menjual banyak kebutuhan hosting dengan harga murah dan kualitas tinggi.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${poppins.variable}`}>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased font-poppins`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
