"use client";
import NavbarAdmin from "@/components/navbarAdmin";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { toast } from "sonner"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Footer from "@/components/footer";

const Home = () => {

  return (
    <>
      <NavbarAdmin />
      <Form />
      <div className="mt-32">
        <Footer />
      </div>
    </>
  );
};

const Form = () => {

    const [kode, setKode] = useState("");
    const router = useRouter();
    const kodeInput = useRef(null)

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const kodeInput2 = kodeInput.current.value;

        if(!kodeInput2) {
          return toast.warning("Harap masukkan kode", {
            description: `© ${new Date().getFullYear()} ${process.env.NEXT_PUBLIC_COMPANY_NAME}.`,
            action: {
                label: "X"
            },
          })
        }
    
        if (kode === process.env.NEXT_PUBLIC_PASSWORD_ADMIN) {
          document.cookie = `role=admin; path=/; max-age=3600`;
          router.push("/admin/dashboard");
        } else {
          return toast.error("Kode admin salah", {
            description: `© ${new Date().getFullYear()} ${process.env.NEXT_PUBLIC_COMPANY_NAME}.`,
            action: {
                label: "X"
            },
          });
        }
      };

  return (
    <div className="flex justify-center items-center">
      <Card className={"w-[340px] mt-24"}>
        <CardHeader>
          <CardTitle className={"text-center text-xl"}>Admin Login</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <div className="flex justify-center items-center mx-auto w-[300px] mb-4">
              <Input
                type="password"
                value={kode}
                onChange={(e) => {
                  setKode(e.target.value);
                }}
                ref={kodeInput}
                placeholder="Masukkan kode admin"
              />
            </div>
            <Button className={"flex mx-auto w-[300px]"} type="submit">
              Login
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Home;
