"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import NavbarAdmin from "@/components/navbarAdmin";
import { toast } from "sonner";
import axios from "axios";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Footer from "@/components/footer";


const Home = () => {
  const [checking, setChecking] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") {
      const isAdmin = document.cookie.includes("role=admin");
      if (!isAdmin) {
        router.push("/admin");
      } else {
        setChecking(false);
      }
    }
  }, []);

  if (checking)
    return (
      <p className="flex justify-center items-center mt-64">
        Sedang mengecek identitas...
      </p>
    );

  return (
    <>
      <NavbarAdmin />
      <GetAllViews />
      <GetAllProduct />
      <Footer />
    </>
  );
};

const GetAllViews = () => {
  const [total, setTotal] = useState(null);
  const router = useRouter();

  const handleReload = () => {
    window.location.reload();
  };
  useEffect(() => {
    const fetchTotal = async () => {
      try {
        axios
          .get("/api/views")
          .then((res) => {
            setTotal(res.data.views);
          })
          .catch((err) => {
            console.error("Error:", err);
          });
      } catch (err) {
        console.error("Gagal fetch total visitor", err);
      }
    };

    fetchTotal();
  }, []);

  return (
    <div className="mt-8 mx-auto flex justify-center">
      <Card className="w-[350px] shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
        <CardHeader>
          <CardTitle className="text-center font-bold text-3xl">
            Total Visitor Web
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <div className="font-semibold text-2xl text-gray-800">
            Total: {total !== null ? total.toLocaleString() : 'Loading...'}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Data visitor ini berdasarkan traffic terakhir.
          </p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button className="w-full" onClick={handleReload}>
            Refresh data
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

const GetAllProduct = () => {
  const [total, setTotal] = useState(null);
  const router = useRouter();

  const handleReload = () => {
    window.location.reload();
  };
  useEffect(() => {
    const fetchTotal = async () => {
      try {
        axios
          .get("/api/products/search")
          .then((res) => {
            setTotal(res.data);
          })
          .catch((err) => {
            console.error("Error:", err);
          });
      } catch (err) {
        console.error("Gagal fetch total produk:", err);
      }
    };

    fetchTotal();
  }, []);

  return (
    <div className="mt-8 mx-auto flex justify-center mb-12">
      <Card className="w-[350px] shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
        <CardHeader>
          <CardTitle className="text-center font-bold text-3xl">
            Total Produk
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <div className="font-semibold text-2xl text-gray-800">
            Total: {total !== null ? total.toLocaleString() : 'Loading...'}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Data produk ini berdasarkan riwayat terakhir.
          </p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button className="w-full" onClick={handleReload}>
            Refresh data
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

export default Home;
