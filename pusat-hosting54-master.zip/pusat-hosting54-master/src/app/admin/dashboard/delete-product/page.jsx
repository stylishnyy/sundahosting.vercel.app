"use client"
import { useEffect, useState } from "react";
import { toast } from "sonner"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import axios from 'axios'
import NavbarAdmin from "@/components/navbarAdmin";
import Footer from "@/components/footer";
import { useRouter } from "next/navigation";

const Home = () => {

  const [checking, setChecking] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      if (typeof window !== "undefined") {
        const isAdmin = document.cookie.includes("role=admin");
        if (!isAdmin) {
          router.push("/admin");
        } else {
          setChecking(false);
        }
      }
    }, []);
  
    if (checking)
      return (
        <p className="flex justify-center items-center mt-64">
          Sedang mengecek identitas...
        </p>
      );

    return (
        <>
            <NavbarAdmin />
            <FormDelete />
            <Footer />
        </>
    );
};

const FormDelete = () => {
    const [products, setProducts] = useState([]);
  
    useEffect(() => {
      axios
        .get("/api/products")
        .then((res) => {
          setProducts(res.data);
        })
        .catch((err) => {
          console.error("Error:", err);
        });
    }, []);
  
    const handleDelete = async (id) => {
      try {
        await axios.delete(`/api/products/${id}`);
        setProducts((prev) => prev.filter((item) => item.id !== parseInt(id))); 
    
        toast.success("Produk sukses dihapus", {
          description: `© ${new Date().getFullYear()} ${process.env.NEXT_PUBLIC_COMPANY_NAME}.`,
          action: { label: "X" },
          duration: 2000
        });
      } catch (err) {
        toast.error("Gagal menghapus produk", {
          description: `© ${new Date().getFullYear()} ${process.env.NEXT_PUBLIC_COMPANY_NAME}.`,
          action: { label: "X" },
          duration: 3000
        });
        console.error("Error:", err);
      }
    };
    
  
    return (
      <section className="bg-white py-16 px-6">
        <div className="max-w-7xl mx-auto grid">
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-5 underline">
            Produk yang sudah di post
          </h2>
          {products.length > 0 ? (
            products.map((item) => (
              <Card className={"mb-5"} key={item.id}>
                <CardHeader>
                  <CardTitle>{item.name}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 space-y-4">
                    <img src={item.image} alt="" width={350} height={350} />
                    <p className="text-center font-poppin font-bold underline">
                      Harga: Rp {item.price.toLocaleString()}
                    </p>
                    <Button onClick={() => handleDelete(item.id)}>Hapus produk</Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <p className="text-center text-gray-600">Produk belum ada...</p>
          )}
        </div>
      </section>
    );
}

export default Home;