"use client";
import NavbarAdmin from "@/components/navbarAdmin";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import axios from "axios";
import Footer from "@/components/footer";

const Home = () => {

  const [checking, setChecking] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") {
      const isAdmin = document.cookie.includes("role=admin");
      if (!isAdmin) {
        router.push("/admin");
      } else {
        setChecking(false);
      }
    }
  }, []);

  if (checking)
    return (
      <p className="flex justify-center items-center mt-64">
        Sedang mengecek identitas...
      </p>
    );

  return (
    <>
      <NavbarAdmin />
      <FormAdd />
      <Footer />
    </>
  );
};

const FormAdd = () => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");


  const handlerSubmit = async (e) => {
    e.preventDefault();

    if (!name || !price || !description || !image) {
      return toast.error("Harap isi semua input", {
        description: `© ${new Date().getFullYear()} ${
          process.env.NEXT_PUBLIC_COMPANY_NAME
        }.`,
        action: {
          label: "X",
        },
      })
    }

    try {
      const res = await axios.post("/api/products", { name, price, description, image });
      return toast.success("Produk berhasil ditambahkan", {
        description: `© ${new Date().getFullYear()} ${
          process.env.NEXT_PUBLIC_COMPANY_NAME
        }.`,
        action: {
          label: "X",
        },
      });
    } catch (err) {
      toast.error("Gagal menambahkan produk", {
        description: `© ${new Date().getFullYear()} ${
          process.env.NEXT_PUBLIC_COMPANY_NAME
        }.`,
        action: {
          label: "X",
        },
      });
      console.error("Error:", err);
    }
  };

  return (
    <div className="flex justify-center items-center">
      <Card className={"w-[340px] mt-24 mb-16"}>
        <CardHeader>
          <CardTitle className={"text-center text-xl font-bold"}>Admin Login</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlerSubmit}>
            <div className="space-y-3 mx-auto">
              <Input
                type="text"
                placeholder="Nama produk"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <Input
                type="number"
                placeholder="Harga produk"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
              <Input
                type="text"
                placeholder="Deskripsi produk"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
              <Input
                type="url"
                placeholder="URL Gambar produk"
                value={image}
                onChange={(e) => setImage(e.target.value)}
              />
              <Button type="submit" className="mx-auto flex justify-center items-center">Tambah produk</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Home;
